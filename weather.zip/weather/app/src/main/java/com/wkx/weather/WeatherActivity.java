package com.wkx.weather;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;

import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.baidu.location.BDAbstractLocationListener;
import com.baidu.location.BDLocation;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.bumptech.glide.Glide;
import com.wkx.weather.db.County;
import com.wkx.weather.gson.Forecast;
import com.wkx.weather.gson.Weather;
import com.wkx.weather.service.AutoUpdateService;
import com.wkx.weather.util.HttpUtil;
import com.wkx.weather.util.Utility;

import org.litepal.crud.ClusterQuery;
import org.litepal.crud.DataSupport;

import java.io.IOException;
import java.util.List;


import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class WeatherActivity extends AppCompatActivity {

    public DrawerLayout drawerLayout;

    public SwipeRefreshLayout swipeRefresh;

    private ScrollView weatherLayout;

    private Button navButton;

    private Button dw_button;

    private TextView titleCity;

    private TextView titleUpdateTime;

    private TextView degreeText;

    private TextView weatherInfoText;

    private LinearLayout forecastLayout;

    private TextView aqiText;

    private TextView pm25Text;

    private TextView comfortText;

    private TextView carWashText;

    private TextView sportText;

    private ImageView bingPicImg;

    private String mWeatherId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 21) {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            getWindow().setStatusBarColor(Color.TRANSPARENT);
        }
        setContentView(R.layout.activity_weather);
        // 初始化各控件
        bingPicImg = (ImageView) findViewById(R.id.bing_pic_img);
        weatherLayout = (ScrollView) findViewById(R.id.weather_layout);
        titleCity = (TextView) findViewById(R.id.title_city);
        titleUpdateTime = (TextView) findViewById(R.id.title_update_time);
        degreeText = (TextView) findViewById(R.id.degree_text);
        weatherInfoText = (TextView) findViewById(R.id.weather_info_text);
        forecastLayout = (LinearLayout) findViewById(R.id.forecast_layout);
        aqiText = (TextView) findViewById(R.id.aqi_text);
        pm25Text = (TextView) findViewById(R.id.pm25_text);
        comfortText = (TextView) findViewById(R.id.comfort_text);
        sportText = (TextView) findViewById(R.id.sport_text);
        swipeRefresh = (SwipeRefreshLayout) findViewById(R.id.swipe_refresh);
        swipeRefresh.setColorSchemeResources(R.color.colorPrimary);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        navButton = (Button) findViewById(R.id.nav_button);
        dw_button = findViewById(R.id.dw_button);
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        String weatherString = prefs.getString("weather", null);
        String forecast = prefs.getString("forecast",null);
        String suggestion = prefs.getString("suggestion",null);
        if (weatherString != null) {
            // 有缓存时直接解析天气数据
            Weather weather = Utility.handleWeatherResponse(weatherString);
            mWeatherId = weather.basic.weatherId;
            showWeatherInfo(weather);
            Weather weather1 = Utility.handleWeatherResponse(forecast);
            showForecast(weather1);
            Weather weather2 = Utility.handleWeatherResponse(suggestion);
            showLife(weather2);
        } else {
            // 无缓存时去服务器查询天气
            mWeatherId = getIntent().getStringExtra("weather_id");
            weatherLayout.setVisibility(View.INVISIBLE);
            requestWeather(mWeatherId);
        }
        swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                requestWeather(mWeatherId);
//                requestForeCast(mWeatherId);
            }
        });
        navButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
        dw_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dw();
            }
        });
        String bingPic = prefs.getString("bing_pic", null);
        if (bingPic != null) {
            Glide.with(this).load(bingPic).into(bingPicImg);
        } else {
            loadBingPic();
        }
    }

    /**
     * 根据天气id请求城市天气信息。
     */
    public void requestWeather(final String weatherId) {
        System.out.println(weatherId);
        String weatherUrl = "https://free-api.heweather.net/s6/weather/now?location=" + weatherId + "&key=1ad0b2e0928948c092f9331e16a150e1";
        HttpUtil.sendOkHttpRequest(weatherUrl, new Callback() {
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String responseText = response.body().string();
                final Weather weather = Utility.handleWeatherResponse(responseText);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (weather != null && "ok".equals(weather.status)) {
                            SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(WeatherActivity.this).edit();
                            editor.putString("weather", responseText);
                            editor.apply();
                            mWeatherId = weather.basic.weatherId;
                            showWeatherInfo(weather);
//                            Toast.makeText(WeatherActivity.this, "更新天气信息成功", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(WeatherActivity.this, "获取天气信息失败", Toast.LENGTH_SHORT).show();
                        }
                        requestForeCast(weatherId);
                        requestSuggestion(weatherId);
                        swipeRefresh.setRefreshing(false);
                    }
                });
            }
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(WeatherActivity.this, "获取天气信息失败", Toast.LENGTH_SHORT).show();
                        swipeRefresh.setRefreshing(false);
                    }
                });
            }
        });
        loadBingPic();
    }

    //天气预报接口
    public void requestForeCast(final String weatherId) {
        System.out.println(weatherId);
        String weatherUrl = "https://free-api.heweather.net/s6/weather/forecast?location=" + weatherId + "&key=1ad0b2e0928948c092f9331e16a150e1";
        HttpUtil.sendOkHttpRequest(weatherUrl, new Callback() {
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String responseText = response.body().string();
                final Weather weather = Utility.handleWeatherResponse(responseText);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (weather.forecastList != null && "ok".equals(weather.status)) {
                            SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(WeatherActivity.this).edit();
                            editor.putString("forecast", responseText);
                            editor.apply();
                            mWeatherId = weather.basic.weatherId;
                            showForecast(weather);
                        } else {
                            Toast.makeText(WeatherActivity.this, "获取天气预报信息失败", Toast.LENGTH_SHORT).show();
                        }
                        swipeRefresh.setRefreshing(false);
                    }
                });
            }
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(WeatherActivity.this, "获取天气预报信息失败", Toast.LENGTH_SHORT).show();
                        swipeRefresh.setRefreshing(false);
                    }
                });
            }
        });
        loadBingPic();
    }

    //生活建议接口
    public void requestSuggestion( String weatherId) {
        System.out.println(weatherId);
        String weatherUrl = "https://free-api.heweather.net/s6/weather/lifestyle?location=" + weatherId + "&key=1ad0b2e0928948c092f9331e16a150e1";
        HttpUtil.sendOkHttpRequest(weatherUrl, new Callback() {
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String responseText = response.body().string();
                final Weather weather = Utility.handleWeatherResponse(responseText);
                System.out.println("text:"+responseText);
                System.out.println("suggestion:"+weather.suggestion);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (weather.suggestion != null && "ok".equals(weather.status)) {
                            SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(WeatherActivity.this).edit();
                            editor.putString("suggestion", responseText);
                            editor.apply();
                            mWeatherId = weather.basic.weatherId;
                            showLife(weather);
                        } else {
                            Toast.makeText(WeatherActivity.this, "获取生活建议信息失败", Toast.LENGTH_SHORT).show();
                        }
                        swipeRefresh.setRefreshing(false);
                    }
                });
            }
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(WeatherActivity.this, "获取生活建议信息失败", Toast.LENGTH_SHORT).show();
                        swipeRefresh.setRefreshing(false);
                    }
                });
            }
        });
        loadBingPic();
    }



    /**
     * 加载必应每日一图
     */
    private void loadBingPic() {
        String requestBingPic = "http://guolin.tech/api/bing_pic";
        HttpUtil.sendOkHttpRequest(requestBingPic, new Callback() {
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String bingPic = response.body().string();
                SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(WeatherActivity.this).edit();
                editor.putString("bing_pic", bingPic);
                editor.apply();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Glide.with(WeatherActivity.this).load(bingPic).into(bingPicImg);
                    }
                });
            }

            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * 处理并展示Weather实体类中的数据。
     */
    private void showWeatherInfo(Weather weather) {
        String cityName = weather.basic.cityName;
        String updateTime = weather.update.updateTime;
        String degree = weather.now.temperature + "℃";
        String weatherInfo = weather.now.info;
        titleCity.setText(cityName);
        String[] time = updateTime.split(" ");
        System.out.println("time:"+time[1]);
        titleUpdateTime.setText("更新时间: "+time[1]);
        degreeText.setText(degree);
        weatherInfoText.setText(weatherInfo);
        forecastLayout.removeAllViews();

        if (weather.now.windDir != null) {
            aqiText.setText(weather.now.windDir);
            pm25Text.setText(weather.now.windSc+"级");
        }
        weatherLayout.setVisibility(View.VISIBLE);
        Intent intent = new Intent(this, AutoUpdateService.class);
        startService(intent);
    }

    public void showForecast(Weather weather){
        String updateTime = weather.update.updateTime;
        String[] time = updateTime.split(" ");
        String[] endTime = time[0].split("-");
        forecastLayout.removeAllViews();
        for (Forecast forecast : weather.forecastList) {
            System.out.println("forecast:"+forecast);
            View view = LayoutInflater.from(this).inflate(R.layout.forecast_item, forecastLayout, false);
            TextView dateText = (TextView) view.findViewById(R.id.date_text);
            TextView tis = (TextView)view.findViewById(R.id.tis);
            TextView infoText = (TextView) view.findViewById(R.id.info_text);
            TextView maxText = (TextView) view.findViewById(R.id.max_text);
            TextView minText = (TextView) view.findViewById(R.id.min_text);
            if (forecast.date.equals(time[0])){
                dateText.setText(forecast.date+"今天");
            }
            else if (Integer.parseInt(forecast.date.split("-")[2])==(Integer.parseInt(endTime[2])+1))
            {
                dateText.setText(forecast.date+"明天");
            }else {
                dateText.setText(forecast.date);
            }
            System.out.println(forecast.con);
            infoText.setText(forecast.con);
            maxText.setText(forecast.max+"℃");
            tis.setText("/");
            minText.setText(forecast.min+"℃");
            System.out.println("view:"+view);
            forecastLayout.addView(view);
        }
        weather.forecastList.clear();
    }

    public void showLife(Weather weather){
        String comfort = "舒适度：" + weather.suggestion.get(4).carWash;
        String sport = "出行建议：" + weather.suggestion.get(4).sport;
        comfortText.setText(comfort);
        sportText.setText(sport);
    }



    public LocationClient mLocationClient = null;
    private MyLocationListener myListener = new MyLocationListener();


//    View.OnClickListener br = new View.OnClickListener() {
//        @Override
//        public void onClick(View v) {
//        }
//    };

    //定位函数
    protected void dw(){
        try {
            mLocationClient = new LocationClient(getApplicationContext());
            mLocationClient.registerLocationListener(myListener);
            LocationClientOption option = new LocationClientOption();
            option.setIsNeedAddress(true);
            option.setScanSpan(0);
            mLocationClient.setLocOption(option);
            mLocationClient.start();

        }
        catch (Exception e){
            Toast.makeText(WeatherActivity.this,"获取位置信息失败",Toast.LENGTH_SHORT).show();
        }
    }
    public class MyLocationListener extends BDAbstractLocationListener {
        @Override
        public void onReceiveLocation(BDLocation location){
             LocationClientOption option = new LocationClientOption();
             option.setIsNeedAddress(true);
            String city = location.getCity();    //获取城市
            List<County> countyList = DataSupport.where("countyname = ?",city.substring(0,city.length()-1)).find(County.class);
            //CN101301301
            requestWeather(countyList.get(0).getWeatherId());
            if (city == null){
                Toast.makeText(WeatherActivity.this,"获取位置信息失败",Toast.LENGTH_SHORT).show();
            }
        }
    }
}
