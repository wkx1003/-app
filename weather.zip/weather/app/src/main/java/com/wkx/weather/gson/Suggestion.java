package com.wkx.weather.gson;

import com.google.gson.annotations.SerializedName;

public class Suggestion {

    @SerializedName("type")
    public String comfort;

    @SerializedName("brf")
    public String carWash;

    @SerializedName("txt")
    public String sport;






}
